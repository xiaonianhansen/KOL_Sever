// JWT 密钥配置
module.exports = {
  JWT_SECRET: process.env.JWT_SECRET || 'kol-secret-key-2024',
  JWT_EXPIRE: '7d'
};