const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const { mockAuthService } = require('../data/mockData');

// 获取所有用户（仅管理员）
router.get('/', authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: '无权访问' });
    }
    
    const users = await mockAuthService.getAllUsers();
    res.json({ success: true, data: users });
  } catch (error) {
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 更新用户权限（仅管理员）
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: '无权操作' });
    }

    const { viewScope } = req.body;
    const updatedUser = await mockAuthService.updateUser(parseInt(req.params.id), { viewScope });
    
    if (!updatedUser) {
      return res.status(404).json({ success: false, message: '用户不存在' });
    }

    res.json({ success: true, data: updatedUser, message: '更新成功' });
  } catch (error) {
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

module.exports = router;