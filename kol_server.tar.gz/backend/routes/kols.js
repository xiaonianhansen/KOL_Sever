const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const { mockKolService } = require('../data/mockData');

// 获取所有达人（支持筛选）
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { platform, category, country, keyword } = req.query;
    const filters = { platform, category, country, keyword };
    const kols = await mockKolService.getAll(filters, req.user);
    res.json({ success: true, data: kols });
  } catch (error) {
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 获取统计数据
router.get('/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await mockKolService.getStats(req.user);
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 获取单个达人详情
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const kol = await mockKolService.getById(parseInt(req.params.id), req.user);
    if (!kol) {
      return res.status(404).json({ success: false, message: '达人不存在或无权访问' });
    }
    res.json({ success: true, data: kol });
  } catch (error) {
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 创建新达人
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { name, platform, followers, category, country, email, contactStatus, notes } = req.body;

    if (!name || !platform || !followers || !category || !country || !email) {
      return res.status(400).json({ success: false, message: '必填字段不能为空' });
    }

    const newKol = await mockKolService.create({
      name,
      platform,
      followers: parseInt(followers),
      category,
      country,
      email,
      contactStatus: contactStatus || '待联系',
      notes: notes || ''
    }, req.user);

    res.status(201).json({ success: true, data: newKol, message: '创建成功' });
  } catch (error) {
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 更新达人信息
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const updatedKol = await mockKolService.update(parseInt(req.params.id), req.body, req.user);
    if (!updatedKol) {
      return res.status(404).json({ success: false, message: '达人不存在或无权修改' });
    }
    res.json({ success: true, data: updatedKol, message: '更新成功' });
  } catch (error) {
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 删除达人
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const deleted = await mockKolService.delete(parseInt(req.params.id), req.user);
    if (!deleted) {
      return res.status(404).json({ success: false, message: '达人不存在或无权删除' });
    }
    res.json({ success: true, message: '删除成功' });
  } catch (error) {
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 批量导入达人
router.post('/batch-import', authMiddleware, async (req, res) => {
  try {
    const { kols } = req.body;

    if (!Array.isArray(kols) || kols.length === 0) {
      return res.status(400).json({ success: false, message: '导入数据不能为空' });
    }

    const results = {
      success: 0,
      failed: 0,
      errors: []
    };

    for (let i = 0; i < kols.length; i++) {
      const kolData = kols[i];
      const { name, platform, followers, category, country, email, contactStatus, notes } = kolData;

      // 验证必填字段
      if (!name || !platform || !followers || !category || !country || !email) {
        results.failed++;
        results.errors.push({
          row: i + 1,
          error: '缺少必填字段'
        });
        continue;
      }

      try {
        await mockKolService.create({
          name,
          platform,
          followers: parseInt(followers),
          category,
          country,
          email,
          contactStatus: contactStatus || '待联系',
          notes: notes || ''
        }, req.user);
        results.success++;
      } catch (error) {
        results.failed++;
        results.errors.push({
          row: i + 1,
          error: error.message || '创建失败'
        });
      }
    }

    res.json({
      success: true,
      data: results,
      message: `导入完成：成功 ${results.success} 条，失败 ${results.failed} 条`
    });
  } catch (error) {
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

module.exports = router;