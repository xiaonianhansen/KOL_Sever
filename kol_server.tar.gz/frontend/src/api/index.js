import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 请求拦截器 - 添加 token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 响应拦截器 - 处理 401 错误
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// 认证相关 API
export const authAPI = {
  login: (username, password) => 
    api.post('/auth/login', { username, password }),
};

// 用户管理 API
export const userAPI = {
  getAll: () => api.get('/users'),
  update: (id, data) => api.put(`/users/${id}`, data),
};

// 达人相关 API
export const kolAPI = {
  getAll: (params) => api.get('/kols', { params }),
  getById: (id) => api.get(`/kols/${id}`),
  create: (data) => api.post('/kols', data),
  update: (id, data) => api.put(`/kols/${id}`, data),
  delete: (id) => api.delete(`/kols/${id}`),
  getStats: () => api.get('/kols/stats'),
  batchImport: (data) => api.post('/kols/batch-import', data),
};

export default api;